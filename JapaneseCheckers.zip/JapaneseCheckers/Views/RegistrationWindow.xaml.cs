﻿using System.Windows;

namespace JapaneseCheckers.Views;

/// <summary>
///     Interaction logic for Registration.xaml
/// </summary>
public partial class Registration : Window
{
    public Registration()
    {
        InitializeComponent();
    }
}