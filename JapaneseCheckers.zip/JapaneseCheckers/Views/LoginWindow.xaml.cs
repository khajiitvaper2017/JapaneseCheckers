﻿using System.Windows;

namespace JapaneseCheckers.Views;

/// <summary>
///     Interaction logic for Login.xaml
/// </summary>
public partial class Login : Window
{
    public Login()
    {
        InitializeComponent();
    }
}