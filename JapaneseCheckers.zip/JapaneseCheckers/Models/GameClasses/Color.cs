﻿namespace JapaneseCheckers.Models.GameClasses;

public enum Color
{
    White,
    Black,
    None
}