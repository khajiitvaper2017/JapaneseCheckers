﻿using System.Windows;

namespace JapaneseCheckers.Views;

/// <summary>
///     Логика взаимодействия для SelectPlayers.xaml
/// </summary>
public partial class SelectPlayers : Window
{
    public SelectPlayers()
    {
        InitializeComponent();
    }
}